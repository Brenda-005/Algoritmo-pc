#include <stdio.h>
#include <locale.h>
#define TAM 5

int main()
{
   setlocale(LC_CTYPE, "");
   float salarios[TAM];
   int i;

   for(i=0; i<TAM; I++){
        printf("Digite o sal�rio do funcion�rio %d: ", (i + 1));
        scanf("%f", &salarios[i]);
   }
   for(i=0; i < TAM; i++){
        printf("Sal�rio do funcion�rio %d: %.2f\n", (i+1), salarios[i]);
   }
   return 0;
}
