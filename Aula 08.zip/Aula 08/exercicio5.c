#include <stdio.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL, "");
    float notas[3][4];
    float medias[3];
    float soma;
    int i, j;
    int maior_estudante = 0;

    // Leitura das notas
    for (i = 0; i < 3; i++)
    {
        soma = 0;

        for (j = 0; j < 4; j++)
        {
            printf("Digite a %d� nota do %d� estudante: ", j + 1, i + 1);
            scanf("%f", &notas[i][j]);

            soma += notas[i][j];
        }

        // Calcula a m�dia do estudante
        medias[i] = soma / 4;
    }

    // Exibe as m�dias
    printf("\n");

    for (i = 0; i < 3; i++)
    {
        printf("M�dia do estudante %d: %.2f\n", i + 1, medias[i]);
    }

    // Identifica a maior m�dia
    for (i = 1; i < 3; i++)
    {
        if (medias[i] > medias[maior_estudante])
        {
            maior_estudante = i;
        }
    }

    printf("Maior m�dia: estudante %d - %.2f\n",
           maior_estudante + 1, medias[maior_estudante]);

    return 0;
}
