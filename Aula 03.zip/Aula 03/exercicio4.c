#include<stdio.h>
#include<locale.h>

int main ()
{
    setlocale(LC_CTYPE, "");
    float potencia, horas, consumo;

    printf("Pot�ncia do equipamento (W)? ");
    scanf("%f", &potencia);

    printf("Horas de uso por dia? ");
    scanf("%f", &horas);

    consumo = (potencia * horas *30)/1000;

    printf("Consumo mensal: %.2f", consumo);

    return 0;




}
