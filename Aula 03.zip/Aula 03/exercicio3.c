#include <stdio.h>
#include<locale.h>

int main() {

    setlocale(LC_CTYPE, "");
    int primeiro, segundo;
    int soma, subtracao, multiplicacao;

    printf("Digite o primeiro n�mero: ");
    scanf("%d", &primeiro);

    printf("Digite o segundo n�mero: ");
    scanf("%d", &segundo);

    soma = primeiro + segundo;
    subtracao = primeiro - segundo;
    multiplicacao = primeiro * segundo;

    printf("Soma: %d\n", soma);
    printf("Subtra��o: %d\n", subtracao);
    printf("Multiplica��o: %d\n", multiplicacao);

    return 0;
}
