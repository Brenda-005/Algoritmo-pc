#include<stdio.h>
#include<locale.h>

int main ()
{
    setlocale(LC_CTYPE, "");
    float peso, altura, imc;

    printf(" Qual � o peso da pessoa em kg? ");
    scanf("%f", &peso);

    printf("Qual � a altura da pessoa em metros? ");
    scanf("%f", &altura);

    imc = peso / (altura*altura);

    printf("O �ndice de Massa Corporal � %.2f kg/m2.\n", imc);

    return 0;

}
