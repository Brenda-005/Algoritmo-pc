#include <stdio.h>
#include <locale.h>

float calcular_area(float base, float altura)
{
    return base * altura;
}

int main()
{
    setlocale(LC_CTYPE, "");

    float base, altura, area;

    base = 5;
    altura = 6;

    printf("A �rea do ret�ngulo �: %.1f cm�\n", calcular_area(base, altura));
    printf("A �rea do ret�ngulo �: %.1f cm�\n", calcular_area(5, 7.8));
    printf("A �rea do ret�ngulo �: %.1f cm�\n", calcular_area(3, 8));
    printf("A �rea do ret�ngulo �: %.1f cm�\n", calcular_area(8, 9));

    return 0;
}
