
#include <stdio.h>
#include <locale.h>

float calcularMedia(float nota1, float nota2) {
    return (nota1 + nota2) / 2;
}

void verificarSituacao(float media) {
    if (media >= 7) {
        printf("Situacao: Aprovado\n");
    } else {
        printf("Situacao: Reprovado\n");
    }
}

int main() {
     setlocale(LC_CTYPE, "");

    float nota1, nota2, media;
    char resposta;

    do {
        printf("Digite a primeira nota: ");
        scanf("%f", &nota1);

        printf("Digite a segunda nota: ");
        scanf("%f", &nota2);

        media = calcularMedia(nota1, nota2);

        printf("Media do aluno: %.1f\n", media);

        verificarSituacao(media);

        printf("Deseja digitar notas de outro aluno (s/n): ");
        scanf(" %c", &resposta);

    } while (resposta == 's' || resposta == 'S');

    return 0;
}
