#include <stdio.h>
#include <locale.h>

void trocar(int *a, int *b) {
    int temp;

    temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    setlocale(LC_CTYPE, "");

    int a, b;

    printf("Digite o valor de a: ");
    scanf("%d", &a);

    printf("Digite o valor de b: ");
    scanf("%d", &b);

    printf("Antes: a=%d b=%d\n", a, b);

    trocar(&a, &b);

    printf("Depois: a=%d b=%d\n", a, b);

    return 0;
}
