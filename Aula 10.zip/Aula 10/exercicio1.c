#include <stdio.h>
#include <locale.h>

float calcular_frete(float peso)
{
    return peso * 4.5;
}
void imprimir_frete(float peso)
{
    printf("Valor do frete: R$ %.2f\n", calcular_frete(peso));
}
int main()
{
    setlocale(LC_CTYPE, "");

    float peso;
    char resp;

    whilw(1){
        printf("\nDigite o peso (kg):  ");
        scanf("%f", &peso);

        printf("Valor do frete: R$ %.2f\n", calcular_frete(peso));

        printf("Deseja calcular outro outro frete? ");
        scanf(" %c", &resp);
    } while(resp == )
