#include <stdio.h>
#include <locale.h>

typedef struct {
    int rgm;
    float nota1;
    float nota2;
    float media;
} Aluno;

void calcular_media(Aluno *aluno) {
    aluno->media = (aluno->nota1 + aluno->nota2) / 2;
}

void cadastrar_aluno(Aluno alunos[], int *quantidade) {
    if (*quantidade >= 10) {
        printf("Limite de alunos atingido!\n");
        return;
    }

    printf("Digite o RGM: ");
    scanf("%d", &alunos[*quantidade].rgm);

    printf("Digite a primeira nota: ");
    scanf("%f", &alunos[*quantidade].nota1);

    printf("Digite a segunda nota: ");
    scanf("%f", &alunos[*quantidade].nota2);

    calcular_media(&alunos[*quantidade]);

    (*quantidade)++;

    printf("Aluno cadastrado com sucesso!\n");
}

void consultar_aluno(Aluno alunos[], int quantidade) {
    int rgmBusca, i, encontrado = 0;

    printf("Digite o RGM para consulta: ");
    scanf("%d", &rgmBusca);

    for (i = 0; i < quantidade; i++) {
        if (alunos[i].rgm == rgmBusca) {
            printf("RGM: %d\n", alunos[i].rgm);
            printf("Media: %.2f\n", alunos[i].media);
            encontrado = 1;
            break;
        }
    }

    if (encontrado == 0) {
        printf("Aluno nao encontrado!\n");
    }
}

void listar_alunos(Aluno alunos[], int quantidade) {
    int i;

    if (quantidade == 0) {
        printf("Nenhum aluno cadastrado!\n");
        return;
    }

    for (i = 0; i < quantidade; i++) {
        printf("\nRGM: %d\n", alunos[i].rgm);
        printf("Nota 1: %.2f\n", alunos[i].nota1);
        printf("Nota 2: %.2f\n", alunos[i].nota2);
        printf("Media: %.2f\n", alunos[i].media);
    }
}

int main() {
    setlocale(LC_CTYPE, "");

    Aluno alunos[10];
    int quantidade = 0;
    int opcao;

    do {
        printf("\n===== SISTEMA ACADEMICO =====\n");
        printf("1 - Cadastrar aluno\n");
        printf("2 - Consultar aluno por RGM\n");
        printf("3 - Listar alunos\n");
        printf("4 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                cadastrar_aluno(alunos, &quantidade);
                break;

            case 2:
                consultar_aluno(alunos, quantidade);
                break;

            case 3:
                listar_alunos(alunos, quantidade);
                break;

            case 4:
                printf("Encerrando o sistema...\n");
                break;

            default:
                printf("Opcao invalida!\n");
        }

    } while (opcao != 4);

    return 0;
}
