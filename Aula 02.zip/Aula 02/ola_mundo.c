#include<stdio.h>

int main()
{
    int idade = 18;
    printf("Voc� tem %d anos de idade.", idade);

    return 0;
}
