#include<stdio.h>
#include<locale.h>
#include<math.h>

int main ()
{
    setlocale(LC_CTYPE, "");
    int nota1, nota2, media;

    printf("Digite a primeira nota: ");
    scanf("%d", &nota1);

    printf("Digite a segunda nota: ");
    scanf("%d", &nota2);

   media = (nota1 + nota2)/2;

   if (media >= 6){
    printf("Parab�ns! Voc� foi aprovado com media: %.2f", media);
   } else {
    printf("Voc� foi reprovado!");
   }

    return 0;
}
