#include<stdio.h>
#include<locale.h>
#include<math.h>

int main ()
{
    setlocale(LC_CTYPE, "");
    floar a, b, c, x1, x2, delta;

    printf("Digite o valor de a: ");
    scanf("%f", &a);

    printf("Digite o valor de b: ");
    scanf("%f", &b);

    prinft("Digite o valor de c: ");
    scanf("%f", &c);

    delta = b*b - 4*a*c;
    x1 = (-b + sqrt(delta))/(2*a);
    x2 = (-b - sqrt(delta))/(2*a);

    printf("Ra�zes da equa��o s�o: %.2f\n", delta);
    printf("x1 = %.2f\n x2 = %.2f: ", x1, x2);

    return 0;
}
