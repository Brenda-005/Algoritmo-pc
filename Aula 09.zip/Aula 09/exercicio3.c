#include <stdio.h>
#include <locale.h>

int main() {

    setlocale(LC_CTYPE, "");
    char linha[100];
    // O modo "r" (read) � utilizado para leitura do ficheiro
    FILE *arquivo = fopen("tabuada.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir o ficheiro. Certifique-se que foi criado.\n");
        return 1;
    }

    // fgets() l� a linha do ficheiro at� ao limite de caracteres ou nova linha
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        printf("%s", linha);
    }

    fclose(arquivo);
    return 0;
}
