#include <stdio.h>
#include<locale.h>

int main() {

    setlocale(LC_CTYPE, "");
    char cpf[12];
    float preco, total = 0;

    // Leitura do CPF
    printf("CPF: ");
    scanf("%11s", cpf);

    // Leitura dos pre�os
    do {
        printf("Preco: ");
        scanf("%f", &preco);

        if (preco != 0) {
            total += preco;
        }

    } while (preco != 0);

    // Exibi��o do resultado
    printf("CPF: %s\n", cpf);
    printf("Total da compra: R$ %.2f\n", total);

    return 0;
}
